import os, re, hmac, hashlib, secrets, sqlite3
from pathlib import Path
from functools import wraps
from flask import Flask, request, redirect, url_for, session, flash, render_template, jsonify

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get("DATABASE_PATH", str(BASE / "keys.db")))
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-this-admin-password")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deploying")
KEY_RE = re.compile(r"^PHTM-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$")
CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS license_keys(
      id INTEGER PRIMARY KEY AUTOINCREMENT, key_hash TEXT UNIQUE NOT NULL,
      last4 TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'unused',
      device_id TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      activated_at TEXT)""")
    c.commit(); return c

def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def make_key():
    s = ''.join(secrets.choice(CHARS) for _ in range(12))
    return 'PHTM-' + '-'.join(s[i:i+4] for i in range(0,12,4))

def admin(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get('admin'): return redirect(url_for('login'))
        return fn(*a, **kw)
    return wrapped

@app.get('/')
def home(): return render_template('index.html')

@app.post('/activate')
def activate():
    key=request.form.get('key','').strip().upper()
    device=request.form.get('device_id','').strip()
    if not KEY_RE.fullmatch(key) or not device or len(device)>128:
        flash('กรุณาตรวจรูปแบบคีย์และ Device ID','error'); return redirect('/')
    c=db(); r=c.execute('SELECT * FROM license_keys WHERE key_hash=?',(sha(key),)).fetchone()
    if not r: msg,cat='ไม่พบคีย์ในฐานข้อมูลของเว็บไซต์นี้','error'
    elif r['status']=='revoked': msg,cat='คีย์ถูกเพิกถอนแล้ว','error'
    elif not r['device_id']:
        c.execute("UPDATE license_keys SET status='active',device_id=?,activated_at=CURRENT_TIMESTAMP WHERE id=?",(device,r['id']))
        c.commit(); msg,cat='เปิดใช้งานสำเร็จ (คีย์ถาวรในระบบของคุณ)','success'
    elif hmac.compare_digest(r['device_id'],device): msg,cat='คีย์นี้เปิดใช้งานบนอุปกรณ์นี้แล้ว','success'
    else: msg,cat='คีย์นี้ผูกกับอุปกรณ์อื่นแล้ว','error'
    c.close(); flash(msg,cat); return redirect('/')

@app.get('/admin/login')
def login(): return render_template('login.html')

@app.post('/admin/login')
def login_post():
    if hmac.compare_digest(request.form.get('password',''),ADMIN_PASSWORD):
        session['admin']=True; return redirect('/admin')
    flash('รหัสผ่านไม่ถูกต้อง','error'); return redirect('/admin/login')

@app.post('/admin/logout')
def logout(): session.clear(); return redirect('/')

@app.get('/admin')
@admin
def dashboard():
    c=db(); rows=c.execute('SELECT * FROM license_keys ORDER BY id DESC LIMIT 200').fetchall()
    counts={r['status']:r['n'] for r in c.execute('SELECT status,COUNT(*) n FROM license_keys GROUP BY status')}
    c.close(); new=session.pop('new_keys',[])
    return render_template('admin.html',rows=rows,counts=counts,new_keys=new)

@app.post('/admin/generate')
@admin
def generate():
    try: n=int(request.form.get('count','1')); assert 1<=n<=50
    except: flash('เลือกจำนวน 1 ถึง 50 คีย์','error'); return redirect('/admin')
    c=db(); made=[]
    for _ in range(n):
        while True:
            k=make_key()
            try:
                c.execute('INSERT INTO license_keys(key_hash,last4) VALUES(?,?)',(sha(k),k[-4:]))
                made.append(k); break
            except sqlite3.IntegrityError: pass
    c.commit(); c.close(); session['new_keys']=made; return redirect('/admin')

@app.post('/admin/revoke/<int:i>')
@admin
def revoke(i):
    c=db(); c.execute("UPDATE license_keys SET status='revoked' WHERE id=?",(i,)); c.commit(); c.close()
    flash('เพิกถอนคีย์แล้ว','success'); return redirect('/admin')

@app.get('/health')
def health(): return jsonify(status='ok')

if __name__=='__main__':
    db().close()
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5000')),debug=False)
