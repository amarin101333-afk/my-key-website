ติดตั้งทดลองใน Android / Pydroid 3
1) แตก ZIP ในโฟลเดอร์ที่หาเจอง่าย
2) เปิด Pydroid 3 > Terminal
3) cd ไปยังโฟลเดอร์โปรเจกต์
4) pip install -r requirements.txt
5) ตั้ง ADMIN_PASSWORD และ SECRET_KEY ก่อนเปิดเว็บสาธารณะ
6) python app.py
7) เปิดเบราว์เซอร์ http://127.0.0.1:5000

หน้าเว็บ: / | หน้าแอดมิน: /admin/login | แดชบอร์ด: /admin

ข้อสำคัญ:
- เป็นระบบคีย์สำหรับเว็บ/แอปของคุณเองเท่านั้น ไม่ใช่คีย์ PHANTOM หรือ Free Fire
- ค่ารหัสผ่านเริ่มต้นใน app.py ใช้ทดลองในเครื่องเท่านั้น ห้าม deploy สาธารณะจนเปลี่ยน ADMIN_PASSWORD และ SECRET_KEY
- SQLite เหมาะกับการทดลอง; โฮสต์ฟรีบางแห่งมี filesystem ชั่วคราวและอาจลบฐานข้อมูลเมื่อรีสตาร์ต/redeploy
- Device ID เป็นค่าที่ผู้ใช้กรอก ไม่ใช่ HWID ที่เชื่อถือได้
- ก่อนใช้งานจริงควรใช้ฐานข้อมูล PostgreSQL ถาวร, HTTPS, rate limiting และ CSRF protection
